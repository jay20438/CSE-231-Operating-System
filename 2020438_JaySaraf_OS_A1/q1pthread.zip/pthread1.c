#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <syscall.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

# define NTHREADS 2

pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;

// Structure definition for storing parameters to pass to a thread.
struct my_thread_parameter {
    char* section;
};


// Custom function to delimit the lines read from a CSV file and return the corresponding values
char* getfield(char* line, int num)
{
    char* tok;
    for (tok = strtok(line, ",");
            tok && *tok;
            tok = strtok(NULL, ",\n"))
    {
        if (!--num)
            return tok;
    }
    return NULL;
}

int read_line_from_file(int fd,char *buffer,int buffersize)
{
	memset(buffer,0,100);
	int i = 0;
	while(i < buffersize-1 && read(fd, &buffer[i], 1) >=0 && errno != EINTR)
	{
		if(buffer[i] == '\n')
		{
			buffer[i] = '\0';
			return 1;
		}
		i++;
		errno = 0;
	}
	return 0;
}

// Thread function to be called when thread joins
void *sectionWise_gradeAvg(void* data)
{
    struct my_thread_parameter *info = data;
	char* pSection = info->section;
	
	printf("Thread number %ld\n", pthread_self());
	
	pthread_mutex_lock( &mutex1 );						
	// Critical Section
	
	int fd = open("student_record.csv",O_RDONLY);

    char line[1024];
    
	int ass1_grade_sum = 0;
    int ass2_grade_sum = 0;
	int ass3_grade_sum = 0;
    int ass4_grade_sum = 0;
    int ass5_grade_sum = 0;
	int ass6_grade_sum = 0;
	
	double ass1_grade_avg = 0.0;
	double ass2_grade_avg = 0.0;
    double ass3_grade_avg = 0.0;
    double ass4_grade_avg = 0.0;
    double ass5_grade_avg = 0.0;
    double ass6_grade_avg = 0.0;
	
    int count = 0;

    while (read_line_from_file(fd,line,sizeof(line)))
    {
        char* tmp = strdup(line);
        char* section =  getfield(tmp, 2);
        tmp = strdup(line);
        char* ass_1g =  getfield(tmp, 3);
        tmp = strdup(line);
        char* ass_2g =  getfield(tmp, 4);
        tmp = strdup(line);
        char* ass_3g =  getfield(tmp, 5);
        tmp = strdup(line);
        char* ass_4g =  getfield(tmp, 6);
        tmp = strdup(line);
        char* ass_5g =  getfield(tmp, 7);
        tmp = strdup(line);
        char* ass_6g =  getfield(tmp, 8);


	if (strcmp(section, pSection) == 0)
	{
		++count;
		ass1_grade_sum = ass1_grade_sum + atoi(ass_1g);
	        ass2_grade_sum = ass2_grade_sum + atoi(ass_2g);
	        ass3_grade_sum = ass3_grade_sum + atoi(ass_3g);
	        ass4_grade_sum = ass4_grade_sum + atoi(ass_4g);
	        ass5_grade_sum = ass5_grade_sum + atoi(ass_5g);
	        ass6_grade_sum = ass6_grade_sum + atoi(ass_6g);
		
	}

        // NOTE strtok clobbers tmp
        free(tmp);
    }

	if ( count > 0) 
	{
    		ass1_grade_avg =  (double) ass1_grade_sum / count;
    		ass2_grade_avg =  (double) ass2_grade_sum / count;
    		ass3_grade_avg =  (double) ass3_grade_sum / count;
    		ass4_grade_avg =  (double) ass4_grade_sum / count;
    		ass5_grade_avg =  (double) ass5_grade_sum / count;
    		ass6_grade_avg =  (double) ass6_grade_sum / count;
	}

	printf("Average marks per assignment for Section %s \n", pSection);
	printf("Section %s | Assignment 1 Avg: %.2f \n", pSection, ass1_grade_avg);
	printf("Section %s | Assignment 2 Avg: %.2f \n", pSection, ass2_grade_avg);
	printf("Section %s | Assignment 3 Avg: %.2f \n", pSection, ass3_grade_avg);
	printf("Section %s | Assignment 4 Avg: %.2f \n", pSection, ass4_grade_avg);
	printf("Section %s | Assignment 5 Avg: %.2f \n", pSection, ass5_grade_avg);
	printf("Section %s | Assignment 6 Avg: %.2f \n", pSection, ass6_grade_avg);
	

	close(fd);
	
	pthread_mutex_unlock( &mutex1 );
	
	free(info);
	return NULL;
}


int main()
{
   pthread_t thread_id[NTHREADS];		// defined threads
   int i, j;
   struct my_thread_parameter *pass_info;
   
   

   for(i=0; i < NTHREADS; i++)
   {
	   if (i == 0)
	   {
		    pass_info = malloc(sizeof(struct my_thread_parameter));
			pass_info->section = "A";
			pthread_create( &thread_id[i], NULL, sectionWise_gradeAvg, pass_info );		// Creating threads
	   }
	   else if (i == 1)
	   {
		    pass_info = malloc(sizeof(struct my_thread_parameter));
			pass_info->section = "B";
			pthread_create( &thread_id[i], NULL, sectionWise_gradeAvg, pass_info );		// Creating another thread	
	   }		   
   }

   for(j=0; j < NTHREADS; j++)
   {
      pthread_join( thread_id[j], NULL); 								// Joining threads to call thread functions.
   }
  
   /* Now that all threads are complete I can print the final result.     */
   /* Without the join I could be printing a value before all the threads */
   /* have been completed.                                                */

   printf("Process Completed...\n");
   
   return 0;
}
