#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

struct assignment
{
	unsigned int id;
	char assignment1_detail[3];
	char assignment2_detail[3];
	char assignment3_detail[3];
	char assignment4_detail[3];
	char assignment5_detail[3];
	char assignment6_detail[3];
	char section;
	int student[13];
	
};


char* getfield(char* line, int num)
{
    char* tok;
    for (tok = strtok(line, ",");
            tok && *tok;
            tok = strtok(NULL, ",\n"))
    {
        if (!--num)
            return tok;
    }
    return NULL;
}


int read_line_from_file(int fd,char *buffer,int buffersize)
{
	memset(buffer,0,100);
	int i = 0;
	while(i < buffersize-1 && read(fd, &buffer[i], 1) >=0 && errno != EINTR)
	{
		if(buffer[i] == '\n')
		{
			buffer[i] = '\0';
			return 1;
		}
		i++;
		errno = 0;
	}
	return 0;
}


int main()
{
	int pid;
	pid = fork();
	
	if(pid < 0)
	{
		printf("Error occured during forking! \n");
		exit(1);
	}
	else if(pid==0)
	{	
		int fd = open("student_record.csv",O_RDONLY);
		if(fd == 0)
		{
			fprintf(stderr,"Error! The file cannot be opened.");
			printf("\n");
			exit(0);
		}

		char line[1024];
		int ass1_grade_sum = 0;
		double ass1_grade_avg = 0.0;
		int ass2_grade_sum = 0;
		double ass2_grade_avg = 0.0;
		int ass3_grade_sum = 0;
		double ass3_grade_avg = 0.0;
		int ass4_grade_sum = 0;
		double ass4_grade_avg = 0.0;
		int ass5_grade_sum = 0;
		double ass5_grade_avg = 0.0;
		int ass6_grade_sum = 0;
		double ass6_grade_avg = 0.0;
		int count = 0;

		while (read_line_from_file(fd,line,sizeof(line)))
		{
			char* tmp = strdup(line);
			char* section =  getfield(tmp, 2);
			tmp = strdup(line);
			char* ass_1g =  getfield(tmp, 3);
			tmp = strdup(line);
			char* ass_2g =  getfield(tmp, 4);
			tmp = strdup(line);
			char* ass_3g =  getfield(tmp, 5);
			tmp = strdup(line);
			char* ass_4g =  getfield(tmp, 6);
			tmp = strdup(line);
			char* ass_5g =  getfield(tmp, 7);
			tmp = strdup(line);
			char* ass_6g =  getfield(tmp, 8);


		if (strcmp(section,"A") == 0)
		{
				++count;
				ass1_grade_sum = ass1_grade_sum + atoi(ass_1g);
				ass2_grade_sum = ass2_grade_sum + atoi(ass_2g);
				ass3_grade_sum = ass3_grade_sum + atoi(ass_3g);
				ass4_grade_sum = ass4_grade_sum + atoi(ass_4g);
				ass5_grade_sum = ass5_grade_sum + atoi(ass_5g);
				ass6_grade_sum = ass6_grade_sum + atoi(ass_6g);
			
		}

			// strtok clobbers tmp
			free(tmp);
		}

		if ( count > 0) 
		{
				ass1_grade_avg =  (double) ass1_grade_sum / count;
				ass2_grade_avg =  (double) ass2_grade_sum / count;
				ass3_grade_avg =  (double) ass3_grade_sum / count;
				ass4_grade_avg =  (double) ass4_grade_sum / count;
				ass5_grade_avg =  (double) ass5_grade_sum / count;
				ass6_grade_avg =  (double) ass6_grade_sum / count;
		}

		printf("Average marks per assignment for Section A \n");
		printf("Assignment 1 Avg: %.2f \n", ass1_grade_avg);
		printf("Assignment 2 Avg: %.2f \n", ass2_grade_avg);
		printf("Assignment 3 Avg: %.2f \n", ass3_grade_avg);
		printf("Assignment 4 Avg: %.2f \n", ass4_grade_avg);
		printf("Assignment 5 Avg: %.2f \n", ass5_grade_avg);
		printf("Assignment 6 Avg: %.2f \n", ass6_grade_avg);
		close(fd);
		exit(0);
	}
	else
	{
	  waitpid(-1,NULL,0);
	  printf("Completed the child process. \n");
	  
	  int fd = open("student_record.csv",O_RDONLY);
	  if(fd == 0)
		{
			fprintf(stderr,"Error! The file cannot be opened.");
			printf("\n");
			exit(0);
		}

		char line[1024];
		int ass1_grade_sum = 0;
		double ass1_grade_avg = 0.0;
		int ass2_grade_sum = 0;
		double ass2_grade_avg = 0.0;
		int ass3_grade_sum = 0;
		double ass3_grade_avg = 0.0;
		int ass4_grade_sum = 0;
		double ass4_grade_avg = 0.0;
		int ass5_grade_sum = 0;
		double ass5_grade_avg = 0.0;
		int ass6_grade_sum = 0;
		double ass6_grade_avg = 0.0;
		int count = 0;

		while (read_line_from_file(fd,line,sizeof(line)))
		{
			char* tmp = strdup(line);
			char* section =  getfield(tmp, 2);
			tmp = strdup(line);
			char* ass_1g =  getfield(tmp, 3);
			tmp = strdup(line);
			char* ass_2g =  getfield(tmp, 4);
			tmp = strdup(line);
			char* ass_3g =  getfield(tmp, 5);
			tmp = strdup(line);
			char* ass_4g =  getfield(tmp, 6);
			tmp = strdup(line);
			char* ass_5g =  getfield(tmp, 7);
			tmp = strdup(line);
			char* ass_6g =  getfield(tmp, 8);


		if (strcmp(section,"B") == 0)
		{
				++count;
				ass1_grade_sum = ass1_grade_sum + atoi(ass_1g);
				ass2_grade_sum = ass2_grade_sum + atoi(ass_2g);
				ass3_grade_sum = ass3_grade_sum + atoi(ass_3g);
				ass4_grade_sum = ass4_grade_sum + atoi(ass_4g);
				ass5_grade_sum = ass5_grade_sum + atoi(ass_5g);
				ass6_grade_sum = ass6_grade_sum + atoi(ass_6g);
			
		}

			//strtok clobbers tmp
			free(tmp);
		}

		if ( count > 0) 
		{
				ass1_grade_avg =  (double) ass1_grade_sum / count;
				ass2_grade_avg =  (double) ass2_grade_sum / count;
				ass3_grade_avg =  (double) ass3_grade_sum / count;
				ass4_grade_avg =  (double) ass4_grade_sum / count;
				ass5_grade_avg =  (double) ass5_grade_sum / count;
				ass6_grade_avg =  (double) ass6_grade_sum / count;
		}

		printf("Average marks per assignment for Section B \n");
		printf("Assignment 1 Avg: %.2f \n", ass1_grade_avg);
		printf("Assignment 2 Avg: %.2f \n", ass2_grade_avg);
		printf("Assignment 3 Avg: %.2f \n", ass3_grade_avg);
		printf("Assignment 4 Avg: %.2f \n", ass4_grade_avg);
		printf("Assignment 5 Avg: %.2f \n", ass5_grade_avg);
		printf("Assignment 6 Avg: %.2f \n", ass6_grade_avg);
		close(fd);
		exit(0);
	}
    return 0;
}
