#include <stdio.h>
#include <stdlib.h>

extern void C(void);
