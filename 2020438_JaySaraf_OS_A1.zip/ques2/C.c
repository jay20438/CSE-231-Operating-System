#include "C.h"

void C()
{
	printf("I'm C function. \n");
	printf("Exiting... \n");
	exit(-1);
}
