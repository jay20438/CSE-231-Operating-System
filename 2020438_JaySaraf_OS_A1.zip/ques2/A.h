#include <stdio.h>

extern void A(unsigned long long a);

