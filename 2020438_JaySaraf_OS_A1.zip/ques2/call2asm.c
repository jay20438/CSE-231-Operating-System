#include <stdio.h>
#include "A.h"
#include "B.h"
#include "C.h"

int main()
{
	unsigned long long a = 3408398438292478402ULL;
	printf("%llu \n", a);
	A(a);

	return 0;
}
